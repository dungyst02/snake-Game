/* File name: STM32_Project_Game_Snake
 *
 * Description: Simple Snake game for STM32
 *
 * Last Changed By:  $Author: $
 * Revision:         $Revision: $
 * Last Changed:     $Date: $April 15, 2022
 *
 * Code sample:
 ******************************************************************************/
/******************************************************************************/
/*                              INCLUDE FILES                                 */
/******************************************************************************/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <misc.h>
#include <timer.h>
#include <system_stm32f4xx.h>
#include <lightsensor.h>
#include <Ucglib.h>
#include <stm32f401re_gpio.h>
#include <stm32f401re_rcc.h>
#include "stm32f401re_syscfg.h"
#include "stm32f401re_exti.h"

/*------------------------------------------------------------Define button-------------------------------------------------------------------------*/
// Define buttons as per your setup

#define BUTTON_UP_PORT      GPIOB
#define BUTTON_UP_PIN       GPIO_Pin_5

#define BUTTON_LEFT_PORT    GPIOB
#define BUTTON_LEFT_PIN     GPIO_Pin_3

#define BUTTON_RIGHT_PORT   GPIOB
#define BUTTON_RIGHT_PIN    GPIO_Pin_0

#define BUTTON_DOWN_PORT    GPIOB
#define BUTTON_DOWN_PIN     GPIO_Pin_4

#define CELL_SIZE 5
#define GRID_WIDTH 12
#define GRID_HEIGHT 24

#define MAX_SNAKE_LENGTH 100
#define INITIAL_SNAKE_LENGTH 3

// Define directions for the snake movement
#define UP 0
#define DOWN 1
#define LEFT 2
#define RIGHT 3


/*--------------------------------------------------------------------------------------------------------------------------------------------------*/

ucg_t ucg;
int grid[GRID_HEIGHT][GRID_WIDTH];
static uint32_t idTimer = NO_TIMER;
int size = 5;
int snakeX[MAX_SNAKE_LENGTH];
int snakeY[MAX_SNAKE_LENGTH];
int currentX, currentY;
int foodX, foodY;
int direction;
int snakeLength;
int score = 0;



/*------------------------------------------------------------------Function Prototype----------------------------------------------------------*/
static void AppInitCommon(void);
void LoadConfiguration(void);
void InitGame(void);
void GenerateFood(void);
void DrawSnake(void);
void DrawFood(void);
void MoveSnake(void);
void CheckCollision(void);
void CheckFoodCollision(void);

static void BUTTON_Interrupt_Init_B1(void);
static void BUTTON_Interrupt_Init_B2(void);
static void BUTTON_Interrupt_Init_B4(void);
static void BUTTON_Interrupt_Init_B5(void);

/*------------------------------------------------------------------------------------------------------------------------------------------------------*/

static void BUTTON_Interrupt_Init_B1(void) {
	// Enable clock for GPIOB
	    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

	    // Configure GPIO for the button
	    GPIO_InitTypeDef GPIO_InitStructure;
	    EXTI_InitTypeDef EXTI_InitStructure;
	    NVIC_InitTypeDef NVIC_InitStructure;

	    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	    GPIO_InitStructure.GPIO_Pin = BUTTON_UP_PIN;
	    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	    GPIO_Init(BUTTON_UP_PORT, &GPIO_InitStructure);

	    // Connect EXTI Line to GPIO Pin
	    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource5);

	    // Configure EXTI line
	    EXTI_InitStructure.EXTI_Line = EXTI_Line5;
	    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	    EXTI_Init(&EXTI_InitStructure);

	    // Configure NVIC
	    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
	    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;
	    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;
	    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	    NVIC_Init(&NVIC_InitStructure);
}

static void BUTTON_Interrupt_Init_B2(void) {
	 // Enable clock for GPIOB
	    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

	    // Configure GPIO for the button
	    GPIO_InitTypeDef GPIO_InitStructure;
	    EXTI_InitTypeDef EXTI_InitStructure;
	    NVIC_InitTypeDef NVIC_InitStructure;

	    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	    GPIO_InitStructure.GPIO_Pin = BUTTON_LEFT_PIN;
	    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	    GPIO_Init(BUTTON_LEFT_PORT, &GPIO_InitStructure);

	    // Connect EXTI Line to GPIO Pin
	    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource5);

	    // Configure EXTI line
	    EXTI_InitStructure.EXTI_Line = EXTI_Line5;
	    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	    EXTI_Init(&EXTI_InitStructure);

	    // Configure NVIC
	    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
	    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;
	    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;
	    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	    NVIC_Init(&NVIC_InitStructure);
}

static void BUTTON_Interrupt_Init_B4(void) {
	 // Enable clock for GPIOB
	    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

	    // Configure GPIO for the button
	    GPIO_InitTypeDef GPIO_InitStructure;
	    EXTI_InitTypeDef EXTI_InitStructure;
	    NVIC_InitTypeDef NVIC_InitStructure;

	    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	    GPIO_InitStructure.GPIO_Pin = BUTTON_RIGHT_PIN;
	    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	    GPIO_Init(BUTTON_RIGHT_PORT, &GPIO_InitStructure);

	    // Connect EXTI Line to GPIO Pin
	    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource5);

	    // Configure EXTI line
	    EXTI_InitStructure.EXTI_Line = EXTI_Line5;
	    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	    EXTI_Init(&EXTI_InitStructure);

	    // Configure NVIC
	    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
	    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;
	    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;
	    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	    NVIC_Init(&NVIC_InitStructure);
}

static void BUTTON_Interrupt_Init_B5(void) {
	 // Enable clock for GPIOB
	    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

	    // Configure GPIO for the button
	    GPIO_InitTypeDef GPIO_InitStructure;
	    EXTI_InitTypeDef EXTI_InitStructure;
	    NVIC_InitTypeDef NVIC_InitStructure;

	    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	    GPIO_InitStructure.GPIO_Pin = BUTTON_DOWN_PIN;
	    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	    GPIO_Init(BUTTON_DOWN_PORT, &GPIO_InitStructure);

	    // Connect EXTI Line to GPIO Pin
	    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource5);

	    // Configure EXTI line
	    EXTI_InitStructure.EXTI_Line = EXTI_Line5;
	    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	    EXTI_Init(&EXTI_InitStructure);

	    // Configure NVIC
	    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
	    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;
	    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;
	    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	    NVIC_Init(&NVIC_InitStructure);
}

void EXTI3_IRQHandler(void) {
    if (EXTI_GetITStatus(EXTI_Line3) != RESET) {
        // Implement button handler for Up
        // Your code here

        // Clear the interrupt flag
        EXTI_ClearITPendingBit(EXTI_Line3);
    }
}

void EXTI0_IRQHandler(void) {
    if (EXTI_GetITStatus(EXTI_Line0) != RESET) {
        // Implement button handler for Right
        // Your code here

        // Clear the interrupt flag
        EXTI_ClearITPendingBit(EXTI_Line0);
    }
}

void EXTI4_IRQHandler(void) {
    if (EXTI_GetITStatus(EXTI_Line4) != RESET) {
        // Implement button handler for Start/Pause
        // Your code here

        // Clear the interrupt flag
        EXTI_ClearITPendingBit(EXTI_Line4);
    }
}

void EXTI9_5_IRQHandler(void) {
    if (EXTI_GetITStatus(EXTI_Line5) != RESET) {
        // Implement button handler for Left
        // Your code here

        // Clear the interrupt flag
        EXTI_ClearITPendingBit(EXTI_Line5);
    }
}

void EXTI15_10_IRQHandler(void) {
    if (EXTI_GetITStatus(EXTI_Line10) != RESET) {
        // Implement button handler for Down
        // Your code here

        // Clear the interrupt flag
        EXTI_ClearITPendingBit(EXTI_Line10);
    }
}

/*------------------------------------------------------------------------------------------------------------------------------------------------------*/

static void AppInitCommon(void){
	SystemCoreClockUpdate();
	TimerInit();
	LightSensor_Init(ADC_READ_MODE_DMA);
	BUTTON_Interrupt_Init_B1();
	BUTTON_Interrupt_Init_B2();
	BUTTON_Interrupt_Init_B4();
	BUTTON_Interrupt_Init_B5();
	Ucglib4WireSWSPI_begin(&ucg, UCG_FONT_MODE_SOLID);
	ucg_ClearScreen(&ucg);
	ucg_SetFont(&ucg, ucg_font_ncenR08_hr);
	ucg_SetColor(&ucg, 0, 255, 255, 255);
	ucg_SetColor(&ucg, 1, 0, 0, 0);
	ucg_SetRotate180(&ucg);
}

void LoadConfiguration(void) {
	ucg_DrawFrame(&ucg, 0, 0, 62, 122);
	ucg_DrawString(&ucg, 65, 12, 0, "Snake Game");
	ucg_DrawString(&ucg, 65, 48, 0, "Score: ");
}

void InitGame(void) {
	 // Initialize the grid
	    memset(grid, 0, sizeof(grid));

	    // Initialize the snake
	    snakeLength = INITIAL_SNAKE_LENGTH;
	    for (int i = 0; i < snakeLength; i++) {
	        snakeX[i] = GRID_WIDTH / 2 - i;
	        snakeY[i] = GRID_HEIGHT / 2;
	        grid[snakeY[i]][snakeX[i]] = 1;
	    }

	    // Initialize the direction
	    direction = RIGHT;

	    // Generate the initial food
	    GenerateFood();

	    // Draw the initial state of the game
	    DrawGame();

	    // Start the timer for snake movement
	    if (idTimer != NO_TIMER) {
	        TimerStop(idTimer);
	    }

	    idTimer = TimerStart("MoveSnake", 500, TIMER_REPEAT_FOREVER, (void*) MoveSnake, NULL);
}

void GenerateFood(void) {
	 // Find an empty cell for the food
	    do {
	        foodX = rand() % GRID_WIDTH;
	        foodY = rand() % GRID_HEIGHT;
	    } while (grid[foodY][foodX] != 0);

	    // Set the food in the grid
	    grid[foodY][foodX] = 2;
}

// Function to draw the current state of the game
void DrawGame(void) {
    // Clear the screen
    ucg_ClearScreen(&ucg);

    // Draw the score
    UpdateScore();

    // Draw the grid
    for (int i = 0; i < GRID_HEIGHT; i++) {
        for (int j = 0; j < GRID_WIDTH; j++) {
            if (grid[i][j] == 1) {
                ucg_SetColor(&ucg, 0, 255, 255, 255);
                ucg_DrawBox(&ucg, j * CELL_SIZE, i * CELL_SIZE, CELL_SIZE, CELL_SIZE);
            } else if (grid[i][j] == 2) {
                ucg_SetColor(&ucg, 0, 255, 0, 0);
                ucg_DrawBox(&ucg, j * CELL_SIZE, i * CELL_SIZE, CELL_SIZE, CELL_SIZE);
            }
        }
    }
}



// Function to move the snake
void MoveSnake(void) {
    // Update the position of the snake based on the current direction
    int newX = snakeX[0];
    int newY = snakeY[0];

    switch (direction) {
        case UP:
            newY--;
            break;
        case DOWN:
            newY++;
            break;
        case LEFT:
            newX--;
            break;
        case RIGHT:
            newX++;
            break;
    }

    // Check for collision with the walls or itself
    if (newX < 0 || newX >= GRID_WIDTH || newY < 0 || newY >= GRID_HEIGHT || grid[newY][newX] == 1) {
        // Game over
        // You can add game over logic here
        TimerStop(idTimer);
        return;
    }

    // Check if the snake has eaten the food
    if (newX == foodX && newY == foodY) {
        // Increase the snake length
        snakeLength++;

        // Increase the score
        score += 10;

        // Generate a new food location
        GenerateFood();

        // Update and display the score
        UpdateScore();
    } else {
        // Move the tail of the snake
        grid[snakeY[snakeLength - 1]][snakeX[snakeLength - 1]] = 0;
    }

    // Move the rest of the snake
    for (int i = snakeLength - 1; i > 0; i--) {
        snakeX[i] = snakeX[i - 1];
        snakeY[i] = snakeY[i - 1];
    }

    // Move the head of the snake
    snakeX[0] = newX;
    snakeY[0] = newY;

    // Update the grid with the new position of the snake
    for (int i = 0; i < snakeLength; i++) {
        grid[snakeY[i]][snakeX[i]] = 1;
    }

    // Draw the updated game state
    DrawGame();
}

void UpdateScore(void) {
    // Clear the area where the score is displayed
    ucg_SetColor(&ucg, 0, 0, 0, 0);
    ucg_DrawBox(&ucg, 0, 0, 50, 10);

    // Set the color for the score text
    ucg_SetColor(&ucg, 0, 255, 255, 255);

    // Draw the score text
    char scoreText[10];
    sprintf(scoreText, "Score: %d", score);
    ucg_DrawString(&ucg, 5, 5, 0, scoreText);
}



int main(void) {
    AppInitCommon();
    LoadConfiguration();
    InitGame();
    while (1) {
    	processTimerScheduler();
    }
    return 0;
}
